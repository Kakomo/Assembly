# Objetivo
Repositório para trabalhos da disciplina "Organização e Arquitetura de Computadores"

# Conteúdos
Este repositório contém programas feitos em linguagem Assembly RISC-V
1) Laboratório 1 - contém programas para a realização de um poligono de N lados, porém a ordenação de pontos não está em pleno funcionamento, fazendo com que linhas se cruzem.
2) Projeto Final - contém programas para a realização do jogo "Snake" e está em pleno funcionamento.
